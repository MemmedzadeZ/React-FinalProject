import styled from "styled-components";

const Container = styled.div`
  margin-top: 30px;
`;

const ContLogo = styled.div`
  margin-left: 90px;
`;

const Logo = styled.img``;

const NavigationDiv = styled.div`
  background-color: #ffeede;
  width: 1500px;
  height: 1500px;
  top: -645px;
  left: 283px;
  border-radius: 50%;
  margin-left: 250px;
  margin-top: -1050px;
`;

export { Container, ContLogo, Logo, NavigationDiv };
