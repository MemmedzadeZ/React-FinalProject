import React from "react";
import { Container, ContLogo, Logo, NavigationDiv } from "./style";
import LogoImg from "./../../foodImages/logo/logo.png";
import { NavLink, Route, Router, Routes } from "react-router-dom";

const Header = () => {
  return (
    <>
      <Container>
        <ContLogo>
          <Logo src={LogoImg} alt="Logo Image" />
        </ContLogo>

        <NavigationDiv>
          <Routes>
            <Route path="/breakfast" />
            <Route path="/lunch" />
            <Route path="/dinner" />
          </Routes>
        </NavigationDiv>

        {/* <NavLink to="/breakfast">Breakfast</NavLink>
        <NavLink to="/lunch">Lunch</NavLink>
        <NavLink to="/dinner">Dinner</NavLink> */}
      </Container>
    </>
  );
};

export default Header;
