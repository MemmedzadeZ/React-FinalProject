import React from "react";
import Header from "../Header/Header";
import CircleWrapper_ from "../Main/CircleWrapper/CircleWrapper";

const TotalComponents = () => {
  return (
    <>
      <Header />
      <CircleWrapper_ />
    </>
  );
};

export default TotalComponents;
