import { useState } from "react";

import database from "../../../../db.json";
import {
  Button,
  CircleWrapper,
  Circle,
  ImageWrapper,
  CircleDiv,
  TransparantDiv,
  TransparantDiv1,
  WhitRectangleDiv,
} from "./style";
const CircleWrapper_ = () => {
  const [rotation, setRotation] = useState(0);

  const handleRotate = () => {
    setRotation((prevRotation) => prevRotation + 45);
  };

  return (
    <div>
      <div>
        <Button onClick={handleRotate}>Rotate</Button>
        <CircleWrapper rotation={rotation}>
          <Circle>
            {database.BreakfastFood.map((item, index) => (
              <ImageWrapper
                key={item.id}
                index={index}
                total={database.BreakfastFood.length}
              >
                <img src={item.image} alt={item.name} />
              </ImageWrapper>
            ))}
          </Circle>
          <CircleDiv />
        </CircleWrapper>
        <TransparantDiv />
        <TransparantDiv1 />
        <WhitRectangleDiv />
      </div>
    </div>
  );
};

export default CircleWrapper_;
