import styled from "styled-components";

const Button = styled.button`
  margin: 20px;
  padding: 10px 20px;
  font-size: 16px;
`;

const CircleDiv = styled.div`
  border: 2px dashed #e87f1e;
  position: absolute;
  width: 442px;
  height: 443px;
  margin-left: -15px;
  border-radius: 50%;
  margin-top: 8px;
  z-index: -1;
`;

const CircleWrapper = styled.div<{ rotation: number }>`
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
  width: 300px;
  height: 300px;
  margin-left: 100vh;
  margin-top: -40vh;
  border-radius: 50%;
  transform: rotate(${(props) => props.rotation}deg);
`;

const Circle = styled.div`
  width: 100%;
  height: 100%;
  position: relative;
  border-radius: 50%;
`;

const ImageWrapper = styled.div<{ index: number; total: number }>`
  position: absolute;
  top: 50%;
  left: 50%;
  width: 60px;
  height: 60px;
  margin: -30px 0 0 -30px;
  transform: rotate(${(props) => props.index * (360 / props.total)}deg)
    translate(200px);

  img {
    width: 160%;
    height: 170%;
    border-radius: 50%;
  }
`;

/////////////////////////

const TransparantDiv = styled.div`
  background-color: white;
  width: 500px;
  height: 500px;
  margin-top: -30px;
  margin-left: 80vh;
  border-radius: 20px;
  z-index: 5px;
  position: absolute;
`;

const TransparantDiv1 = styled.div`
  background-color: white;
  width: 800px;
  height: 800px;
  margin-top: -75px;
  margin-left: 100vh;
  z-index: 5;
  position: absolute;
  border-radius: 50%; /* This makes the div a circle */
`;

const WhitRectangleDiv = styled.div`
  position: absolute;
  width: 4px;
  height: 40px;
  left: 90vh;
  top: 51vh;
  transform: rotate(-28deg);

  border-top: 100px solid transparent;
  border-left: 100px solid white;
`;
export {
  Button,
  CircleWrapper,
  Circle,
  ImageWrapper,
  CircleDiv,
  TransparantDiv,
  TransparantDiv1,
  WhitRectangleDiv,
};
