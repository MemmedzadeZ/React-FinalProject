import { useState } from "react";

import TotalComponents from "./components/TotalComp/TotalComponents";
import { Route, Routes } from "react-router-dom";

function App() {
  return (
    <>
      {" "}
      <Routes>
        <Route path="/home" element={<TotalComponents />} />
      </Routes>
    </>
  );
}

export default App;
